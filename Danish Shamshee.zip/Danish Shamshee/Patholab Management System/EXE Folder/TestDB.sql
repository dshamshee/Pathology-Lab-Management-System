
conn shamshee/shamshee;
drop user test CASCADE;
create user test identified by test ;
grant resource to test;
grant create session to test ;
grant dba to test ; 
conn test/test;


CREATE TABLE Admin (
    Adin_User_Name varchar(20) constraint Admin_UID_PK PRIMARY KEY,
    first_name VARCHAR2(15),
    last_name VARCHAR2(15),
    password VARCHAR2(20),
    email VARCHAR2(30)
);
insert into admin values ('admin','Danish','Shamshee','admin','admin@gmail.com');


create table Employee (
    Full_Name varchar(30) not null,
    Phone char(10) constraint Emp_phno_PK primary key,
    AdharNO number not null, 
    Gender varchar(20) check (Gender in ('Male','Female','Transgender')) not null, 
    address varchar (50) not null,
    Profession varchar(30) not null,
    salary number not null
);
insert into Employee values ('Employee1','9430856365','123456','Male','Patna','developer',15000);
insert into Employee values ('Employee2','9905135881','55246','Male','Patna','developer',15000);



create table User_SignUp(
    User_ID char(5) constraint User_UID_PK primary key,
    User_Name varchar(20) unique not null,
    email_ID varchar(20) unique not null, 
    password varchar(20) not null,
    Phone char(10) references Employee(Phone) not null
);
insert into User_SignUp values ('u01','user1','user@gmail.com','user123',9430856365);

create table Pathologist (
    PH_ID char(5) constraint Pathol_ID_PK primary key,
    Name varchar(30) not null, 
    Qualificaton varchar(20) not null, 
    Phone number not null, 
    AdharNo number not null, 
    Address varchar(50) not null,
    Comminsion number not null 
);
-- insert into Pathologist values ('P01','xyz','xyz',123456, 123456,'patna',10);


create table TestChategory(
    Chid char(5) constraint Tch_chid_PK primary key,
    ChName varchar(50)
);
insert into TestChategory values('CH01','LFT');
insert into TestChategory values('CH02','KFT');

create table Test (
    Tid char(5) constraint test_Tid_PK primary key,
    TName varchar(50) not null, 
    Cost number not null, 
    MinRange number not null, 
    MaxRange number not null,
    -- Description varchar(100), 
    Chid char(5) references TestChategory(Chid)
);
insert into test values ('T01','ALT',150,50,100,'CH01');
insert into test values ('T02','AST',300,40,90,'CH01');
insert into test values ('T03','ALP',200,30,80,'CH01');
insert into test values ('T04','GGT',200,30,80,'CH01');
insert into test values ('T05','PT',200,30,80,'CH01');
insert into test values ('T06','LD',200,30,80,'CH01');
insert into test values ('T07','BILIRUBIN',200,30,80,'CH01');
insert into test values ('T08','BLOOD UREA',250,60,89,'CH02');
insert into test values ('T09','BLOOD UREA NITROGEN',220,20,50,'CH02');
insert into test values ('T10','CREATININ',250,35,70,'CH02');
insert into test values ('T11','URIC ACID',180,50,90,'CH02');
insert into test values ('T12','CALCIUM',230,20,80,'CH02');


-- create table TestSpecification (
--     Tid char(5) references Test(Tid),
--     Age number not null, 
--     Weight number not null, 
--     Gender varchar(12) check (Gender in ('Male', 'Female', 'child')),
--     MinRange number not null, 
--     MaxRange number not null
-- );


create table Patient (
    Pid char(5) constraint Patient_pid_PK primary key, 
    Name varchar(50) not null,
    Age number not null, 
    Gender varchar(12) check (Gender in ('Male', 'Female', 'Tansgender')), 
    phone char(10) not null,
    User_ID char(5) references User_SignUp(User_ID) not null,
    pdate varchar(12) not null,
    refby varchar(30) not null
);




-- insert  into patient values ('P01','John',26,'Male','1234567890','u01', '22-03-2024','doctor');
-- insert  into patient values ('P02','Akhanda Nanad Tripathi',40,'Male','987654321','u01','22-03-2024','doctor');



create table Patient_Test_Observation (
    Pid char(5) references Patient(Pid) not null, 
    Tid char(5) references Test(Tid) not null,
    Result number null
);
-- insert  into Patient_Test_Observation values('P01','T01',60);
-- insert  into Patient_Test_Observation values('P01','T02',40);
-- insert  into Patient_Test_Observation values('P02','T03',55);
-- insert  into Patient_Test_Observation values('P02','T01',80);


-- create table Bill (
--     Pid char(5) references Patient(Pid) not null, 
--     Tid char(5) references Test(Tid) not null, 
--     Total_Amount number not null, 
--     Advance_Payment number not null, 
--     Dues_Payment number not null
--     -- Status varchar(15) check (Status in ('Processing','Pending', 'Done'))
-- );

set linesize 155;



-- Patient Test Report Data Fetching Query

-- select pt.name, pto.tid, minrange, result, maxrange from patient_test_observation pto, test ts, patient pt where pto.pid = 'P01'
--  and pto.tid = ts.tid  and pto.pid = pt.pid;


 select ts.tname, pto.result, ts.minrange, ts.maxrange from patient_test_observation pto, test ts where pto.tid = ts.tid and pto.pid = 'P1';


-- select ts.tname, pto.result, ts.minrange, ts.maxrange from patient_test_observation pto, test ts where pto.tid = ts.tid;



-- Inserting Patient Records
insert into Patient values ('P1','Danish',20,'Male','9430856365','u01','22-03-2024','DR.Amit Kumar');
insert into Patient values ('P2','Emma',25,'Female','9430856366','u01','22-03-2024','DR.Amit Kumar');
insert into Patient values ('P3','John',30,'Male','9430856367','u01','22-03-2024','DR.Amit Kumar');
insert into Patient values ('P4','Sophia',22,'Female','9430856368','u01','22-03-2024','DR.Amit Kumar');
insert into Patient values ('P5','Michael',35,'Male','9430856369','u01','22-03-2024','DR.Amit Kumar');
insert into Patient values ('P6','Olivia',28,'Female','9430856370','u01','22-03-2024','DR.Amit Kumar');
insert into Patient values ('P7','William',40,'Male','9430856371','u01','22-03-2024','DR.Amit Kumar');
insert into Patient values ('P8','Ava',32,'Female','9430856372','u01','22-03-2024','DR.Amit Kumar');
insert into Patient values ('P9','James',45,'Male','9430856373','u01','22-03-2024','DR.Amit Kumar');
insert into Patient values ('P10','Isabella',29,'Female','9430856374','u01','22-03-2024','DR.Amit Kumar');
insert into Patient values ('P11','Angel priya',29,'Female','9430856425','u01','22-03-2024','DR.Amit Kumar');




 
-- inserting data into Employee table

insert into Employee values ('Priya Patel','9430856366','123456789013','Female','Mumbai','Designer',20000);
insert into Employee values ('Amit Kumar','9430856367','123456789014','Male','Delhi','Manager',25000);
insert into Employee values ('Neha Singh','9430856368','123456789015','Female','Jaipur','Engineer',18000);
insert into Employee values ('Ankit Gupta','9430856369','123456789016','Male','Kolkata','Analyst',22000);
insert into Employee values ('Pooja Mishra','9430856370','123456789017','Female','Lucknow','Tester',17000);
insert into Employee values ('Rajesh Tiwari','9430856371','123456789018','Male','Chennai','Programmer',20000);
insert into Employee values ('Sneha Reddy','9430856372','123456789019','Female','Hyderabad','Consultant',23000);
insert into Employee values ('Vikram Verma','9430856373','123456789020','Male','Bangalore','Architect',28000);
insert into Employee values ('Deepika Malhotra','9430856374','123456789021','Female','Ahmedabad','Developer',19000);
insert into Employee values ('Karan Sharma','9430856375','123456789022','Male','Pune','Manager',25000);
insert into Employee values ('Manisha Patel','9430856376','123456789023','Female','Surat','Analyst',22000);
insert into Employee values ('Alok Kumar','9430856377','123456789024','Male','Nagpur','Tester',17000);

-- inserting data into pathologist table

INSERT INTO Pathologist VALUES ('PH01', 'Rahul Sharma', 'MD Pathology', 9430856365, 123456789012, 'Patna', 1000);
INSERT INTO Pathologist VALUES ('PH02', 'Priya Patel', 'MBBS', 9430856366, 123456789013, 'Mumbai', 1200);
INSERT INTO Pathologist VALUES ('PH03', 'Amit Kumar', 'MD Pathology', 9430856367, 123456789014, 'Delhi', 1100);
INSERT INTO Pathologist VALUES ('PH04', 'Neha Singh', 'MBBS', 9430856368, 123456789015, 'Jaipur', 1300);
INSERT INTO Pathologist VALUES ('PH05', 'Ankit Gupta', 'MD Pathology', 9430856369, 123456789016, 'Kolkata', 1050);
INSERT INTO Pathologist VALUES ('PH06', 'Pooja Mishra', 'MBBS', 9430856370, 123456789017, 'Lucknow', 1150);
INSERT INTO Pathologist VALUES ('PH07', 'Rajesh Tiwari', 'MD Pathology', 9430856371, 123456789018, 'Chennai', 1250);
INSERT INTO Pathologist VALUES ('PH08', 'Sneha Reddy', 'MBBS', 9430856372, 123456789019, 'Hyderabad', 1350);
INSERT INTO Pathologist VALUES ('PH09', 'Vikram Verma', 'MD Pathology', 9430856373, 123456789020, 'Bangalore', 1080);
INSERT INTO Pathologist VALUES ('PH10', 'Deepika Malhotra', 'MBBS', 9430856374, 123456789021, 'Ahmedabad', 1180);

commit ;



create table bill (
    b_no char(5) constraint bill_Bno_PK primary key,
    b_date varchar(15),
    total_amt decimal(7, 2),
    Advance_Payment decimal(7, 2),
    -- discount decimal(5, 2),
    dues decimal(7, 2),
    pid char(5)  references patient(pid)
    );
    -- insert into bill values ('b01','20/03/2024',200,100,100,'P01');



create table bill_test(
    s_no number primary key,
    b_no char(5) references bill(b_no),
    tid char(5) references  test(tid)
);

-- insert into bill_test values